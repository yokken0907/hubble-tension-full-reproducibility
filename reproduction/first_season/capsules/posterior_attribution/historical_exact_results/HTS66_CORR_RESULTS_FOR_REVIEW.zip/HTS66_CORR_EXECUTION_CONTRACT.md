# HTS66_CORR execution contract

## Classification target
`PASS_HTS66_OUTPUT_MANIFEST_CANONICALIZATION_WITH_NO_SCIENTIFIC_CHANGE`

## Exact input
- `HTS66_RESULTS_FOR_REVIEW.zip`
- outer SHA256:
  `405b0133c9cf32f9de81b8f99435625fc9f58b835f3940dcf02b3bee44e25b22`

## Defect
The HTS66 result ZIP has a valid outer sidecar and ZIP CRC, and its scientific/audit
classification is PASS, but it omits an output-level `SHA256SUMS.txt`.

## Allowed operation
- verify exact source outer SHA256, CRC, PASS classification and independent audit
- preserve every original member byte-for-byte
- add a member-freeze table, packaging audit, correction classification and internal manifest
- independently verify the corrected package

## Forbidden operation
- no chain access
- no scientific recomputation
- no numerical alteration
- no change to `HTS66_CLASSIFICATION.tsv`
- no new scientific interpretation or branch selection
