# HTS66_CORR run instructions

Keep the exact original `HTS66_RESULTS_FOR_REVIEW.zip` in Downloads.

Preflight:
```bash
HTS66_CORR_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Expected outputs:
- `HTS66_CORR_RESULTS_FOR_REVIEW.zip`
- `HTS66_CORR_RESULTS_FOR_REVIEW.zip.sha256`
- `HTS66_CORR_RUN_LOG.txt`
