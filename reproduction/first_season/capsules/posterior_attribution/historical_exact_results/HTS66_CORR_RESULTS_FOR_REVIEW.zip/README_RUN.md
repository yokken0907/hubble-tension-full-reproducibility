# HTS66 run instructions

Place the exact HTS59–HTS65 result ZIPs in Downloads or under:

`<HISTORICAL_WSL_RUNTIME_PATH>

Preflight:
```bash
HTS66_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Expected outputs:
- `HTS66_RESULTS_FOR_REVIEW.zip`
- `HTS66_RESULTS_FOR_REVIEW.zip.sha256`
- `HTS66_RUN_LOG.txt`
