# HTS65 canonicalization audit

`PASS_EXHAUSTIVE_COALITION_PARTITION_SENSITIVITY_AUDIT`

Integrity:
- outer ZIP SHA256: `d1a74c3714434211848c16488201db8e66c9be1127a3aa235be98cabe8590efd`
- ZIP CRC: PASS
- internal SHA256 manifest: 30/30 PASS
- independent raw-chain and all-LOO reconstruction: PASS
- maximum saved-summary reconstruction error: `8.88e-16`

Primary results:
- partition-stable directed edges: 11/14
- partition-sensitive directed edges: 3/14
- top-variable turnover: BASE_TO_ACT forward and BASE_TO_PR4 forward
- BASE_TO_ACT reverse is sensitive through effective-variable-count range
- maximum variable Owen-share range across all partitions: `0.0982351`
- maximum partition effective-count range: `0.516971`

Partition stability does not override HTS64 basis sensitivity.
