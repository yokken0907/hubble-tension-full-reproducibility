# HTS62 execution report

`PASS_FIXED_BLOCK_SHAPLEY_AND_ORDER_SENSITIVITY_AUDIT`

HTS62 decomposes the HTS59 conditional four-dimensional posterior distance between fixed coordinate blocks using both sequential orders and their symmetric Shapley average.
