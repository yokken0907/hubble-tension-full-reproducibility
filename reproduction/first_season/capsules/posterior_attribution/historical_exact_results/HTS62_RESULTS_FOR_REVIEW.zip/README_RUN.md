# HTS62 run instructions

The package first searches recursively under:

`<HISTORICAL_WSL_RUNTIME_PATH>

Preflight:
```bash
HTS62_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Expected outputs:
- `HTS62_RESULTS_FOR_REVIEW.zip`
- `HTS62_RESULTS_FOR_REVIEW.zip.sha256`
- `HTS62_RUN_LOG.txt`
