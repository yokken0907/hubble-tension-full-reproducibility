# HTS60 execution report

`PASS_CONDITIONAL_4D_EIGENMODE_LOCALIZATION_AUDIT`

HTS60 decomposes the HTS59 conditional four-dimensional residual into exact source-posterior conditional-correlation eigenmodes. Mode loadings are linear diagnostics in conditionally standardized direct variables, not new physical parameters.
