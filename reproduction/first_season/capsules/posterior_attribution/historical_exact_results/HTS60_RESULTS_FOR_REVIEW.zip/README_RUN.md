# HTS60 run instructions

The package first searches recursively under:

`<HISTORICAL_WSL_RUNTIME_PATH>

Preflight:
```bash
HTS60_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Expected outputs:
- `HTS60_RESULTS_FOR_REVIEW.zip`
- `HTS60_RESULTS_FOR_REVIEW.zip.sha256`
- `HTS60_RUN_LOG.txt`
