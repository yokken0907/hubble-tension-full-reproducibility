# HTS59 execution report

`PASS_TN2D_SUFFICIENCY_AND_CONDITIONAL_4D_RESIDUAL_AUDIT`

HTS59 decomposes each directed release-edge displacement into the frozen tangent-normal marginal distance and the conditional residual in omega_b, tau, n_s and logA.
