# HTS59 run instructions

The package searches recursively under `<HISTORICAL_WSL_RUNTIME_PATH> before any acquisition.

Preflight:
```bash
HTS59_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Outputs: `HTS59_RESULTS_FOR_REVIEW.zip`, sidecar SHA256 and `HTS59_RUN_LOG.txt`.
