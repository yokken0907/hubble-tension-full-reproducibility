# HTS64 execution report

`PASS_WITHIN_BLOCK_REPARAMETERIZATION_INVARIANCE_AUDIT`

HTS64 stress-tests HTS63 coordinate allocations under 49 predeclared within-block rotations and a logA-2tau amplitude reparameterization while requiring exact total distance and fixed-block invariance.
