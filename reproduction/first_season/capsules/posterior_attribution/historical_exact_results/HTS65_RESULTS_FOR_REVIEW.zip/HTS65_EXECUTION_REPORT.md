# HTS65 execution report

`PASS_EXHAUSTIVE_COALITION_PARTITION_SENSITIVITY_AUDIT`

HTS65 exhaustively enumerates all 15 set partitions of the four fixed conditional coordinates and recomputes coalition-respecting Owen allocations. The audit tests coalition-structure dependence without treating arbitrary partitions as physical sectors.
