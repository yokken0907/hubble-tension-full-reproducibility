# HTS65 run instructions

The package first searches recursively under:

`<HISTORICAL_WSL_RUNTIME_PATH>

Preflight:
```bash
HTS65_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Expected outputs:
- `HTS65_RESULTS_FOR_REVIEW.zip`
- `HTS65_RESULTS_FOR_REVIEW.zip.sha256`
- `HTS65_RUN_LOG.txt`
