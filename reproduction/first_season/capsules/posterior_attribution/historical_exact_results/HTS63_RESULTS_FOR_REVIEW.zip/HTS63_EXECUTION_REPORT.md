# HTS63 execution report

`PASS_EXACT_VARIABLE_SHAPLEY_AND_OWEN_COALITION_AUDIT`

HTS63 compares exact unrestricted four-variable Shapley allocations with coalition-respecting Owen allocations for the two fixed HTS62 coordinate blocks.
