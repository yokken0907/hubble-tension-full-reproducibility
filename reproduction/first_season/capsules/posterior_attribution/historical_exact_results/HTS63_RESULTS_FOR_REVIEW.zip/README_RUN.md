# HTS63 run instructions

The package first searches recursively under:

`<HISTORICAL_WSL_RUNTIME_PATH>

Preflight:
```bash
HTS63_PREFLIGHT_ONLY=1 bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Full run:
```bash
bash <HISTORICAL_WSL_RUNTIME_PATH>
```

Expected outputs:
- `HTS63_RESULTS_FOR_REVIEW.zip`
- `HTS63_RESULTS_FOR_REVIEW.zip.sha256`
- `HTS63_RUN_LOG.txt`
