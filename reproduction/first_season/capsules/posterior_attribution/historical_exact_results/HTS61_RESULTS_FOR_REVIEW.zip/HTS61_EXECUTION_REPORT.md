# HTS61 execution report

`PASS_CONDITIONAL_EIGENMODE_IDENTIFIABILITY_AND_SUBSPACE_STABILITY_AUDIT`

HTS61 audits whether HTS60 conditional eigenmodes are individually identifiable or only stable as near-degenerate subspaces.
